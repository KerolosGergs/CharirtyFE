export interface Complaint {
  id: number;
  time: string;
  complainantType: string;
  complaintAbout: string;
  serviceComplaint: string;
  complaintType: string;
  status: string;
  isActive: boolean;
}

export interface ComplaintColumn {
  key: keyof Complaint;
  label: string;
  sortable: boolean;
}

