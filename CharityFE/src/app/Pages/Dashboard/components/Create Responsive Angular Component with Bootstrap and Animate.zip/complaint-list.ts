import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Complaint, ComplaintColumn } from '../models/complaint.interface';

@Component({
  selector: 'app-complaint-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './complaint-list.html',
  styleUrls: ['./complaint-list.scss']
})
export class ComplaintListComponent implements OnInit {
  complaints: Complaint[] = [];
  filteredComplaints: Complaint[] = [];
  searchTerm: string = '';
  selectedComplaints: Set<number> = new Set();
  selectAll: boolean = false;

  columns: ComplaintColumn[] = [
    { key: 'time', label: 'الوقت', sortable: true },
    { key: 'complainantType', label: 'شكوى من نوع', sortable: true },
    { key: 'complaintAbout', label: 'شكوى عن خدمة', sortable: true },
    { key: 'serviceComplaint', label: 'شكوى عن خدمة', sortable: true },
    { key: 'complaintType', label: 'شكوى عن نوع', sortable: true },
    { key: 'status', label: 'الحالة', sortable: true }
  ];

  ngOnInit(): void {
    this.loadComplaints();
    this.filteredComplaints = [...this.complaints];
  }

  loadComplaints(): void {
    // Sample data based on the image
    this.complaints = [
      {
        id: 1,
        time: '9:30 PM',
        complainantType: 'شكوى أخرى',
        complaintAbout: 'شكوى عن خدمة',
        serviceComplaint: 'تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال',
        complaintType: 'شكوى عن نوع',
        status: 'سعيد أحمد',
        isActive: true
      },
      {
        id: 2,
        time: '9:30 PM',
        complainantType: 'شكوى أخرى',
        complaintAbout: 'شكوى عن خدمة',
        serviceComplaint: 'تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال',
        complaintType: 'شكوى عن نوع',
        status: 'سعيد أحمد',
        isActive: true
      },
      {
        id: 3,
        time: '9:30 PM',
        complainantType: 'شكوى أخرى',
        complaintAbout: 'شكوى عن خدمة',
        serviceComplaint: 'تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال',
        complaintType: 'شكوى عن نوع',
        status: 'سعيد أحمد',
        isActive: true
      },
      {
        id: 4,
        time: '9:30 PM',
        complainantType: 'شكوى أخرى',
        complaintAbout: 'شكوى عن خدمة',
        serviceComplaint: 'تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال',
        complaintType: 'شكوى عن نوع',
        status: 'سعيد أحمد',
        isActive: true
      },
      {
        id: 5,
        time: '9:30 PM',
        complainantType: 'شكوى أخرى',
        complaintAbout: 'شكوى عن خدمة',
        serviceComplaint: 'تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال',
        complaintType: 'شكوى عن نوع',
        status: 'سعيد أحمد',
        isActive: true
      },
      {
        id: 6,
        time: '9:30 PM',
        complainantType: 'شكوى أخرى',
        complaintAbout: 'شكوى عن خدمة',
        serviceComplaint: 'تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال',
        complaintType: 'شكوى عن نوع',
        status: 'سعيد أحمد',
        isActive: true
      },
      {
        id: 7,
        time: '9:30 PM',
        complainantType: 'شكوى أخرى',
        complaintAbout: 'شكوى عن خدمة',
        serviceComplaint: 'تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال تم شكوى الاستقبال',
        complaintType: 'شكوى عن نوع',
        status: 'سعيد أحمد',
        isActive: true
      }
    ];
  }

  onSearch(): void {
    if (!this.searchTerm.trim()) {
      this.filteredComplaints = [...this.complaints];
    } else {
      this.filteredComplaints = this.complaints.filter(complaint =>
        Object.values(complaint).some(value =>
          value.toString().toLowerCase().includes(this.searchTerm.toLowerCase())
        )
      );
    }
  }

  toggleSelectAll(): void {
    if (this.selectAll) {
      this.selectedComplaints.clear();
      this.filteredComplaints.forEach(complaint => {
        this.selectedComplaints.add(complaint.id);
      });
    } else {
      this.selectedComplaints.clear();
    }
  }

  toggleComplaintSelection(complaintId: number): void {
    if (this.selectedComplaints.has(complaintId)) {
      this.selectedComplaints.delete(complaintId);
    } else {
      this.selectedComplaints.add(complaintId);
    }
    this.updateSelectAllState();
  }

  updateSelectAllState(): void {
    const visibleComplaintIds = this.filteredComplaints.map(c => c.id);
    this.selectAll = visibleComplaintIds.length > 0 && 
      visibleComplaintIds.every(id => this.selectedComplaints.has(id));
  }

  isComplaintSelected(complaintId: number): boolean {
    return this.selectedComplaints.has(complaintId);
  }

  deleteComplaint(complaintId: number): void {
    this.complaints = this.complaints.filter(c => c.id !== complaintId);
    this.selectedComplaints.delete(complaintId);
    this.onSearch();
  }

  editComplaint(complaintId: number): void {
    // Placeholder for edit functionality
    console.log('Edit complaint:', complaintId);
  }

  viewComplaint(complaintId: number): void {
    // Placeholder for view functionality
    console.log('View complaint:', complaintId);
  }

  trackByComplaintId(index: number, complaint: Complaint): number {
    return complaint.id;
  }
}

